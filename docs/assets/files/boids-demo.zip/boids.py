import random
from config import *
from utils import distance, normalize_vector, limit_vector

class Boid:
    def __init__(self):
        """初始化Boid个体的位置和速度"""
        # 随机初始位置
        self.position = (
            random.uniform(0, WINDOW_WIDTH),
            random.uniform(0, WINDOW_HEIGHT)
        )
        
        # 随机初始速度
        angle = random.uniform(0, 2 * 3.14159)
        speed = random.uniform(MIN_SPEED, MAX_SPEED)
        self.velocity = (
            speed * random.uniform(-1, 1),
            speed * random.uniform(-1, 1)
        )
        self.velocity = normalize_vector(self.velocity)
        self.velocity = (
            self.velocity[0] * speed,
            self.velocity[1] * speed
        )
    
    def get_neighbors(self, boids):
        """获取视野范围内的邻居"""
        neighbors = []
        for boid in boids:
            if boid is self:
                continue
            if distance(self.position, boid.position) < PERCEPTION_RADIUS:
                neighbors.append(boid)
        return neighbors
    
    def separation(self, neighbors):
        """分离规则：远离附近的个体"""
        if not neighbors:
            return (0, 0)
        
        separation_vector = (0, 0)
        for neighbor in neighbors:
            dist = distance(self.position, neighbor.position)
            if dist < SEPARATION_DISTANCE and dist > 0:
                # 距离越近，分离力越大
                separation_vector = (
                    separation_vector[0] + (self.position[0] - neighbor.position[0]) / dist,
                    separation_vector[1] + (self.position[1] - neighbor.position[1]) / dist
                )
        
        return normalize_vector(separation_vector)
    
    def alignment(self, neighbors):
        """对齐规则：与邻居的速度保持一致"""
        if not neighbors:
            return (0, 0)
        
        avg_velocity = (0, 0)
        for neighbor in neighbors:
            avg_velocity = (
                avg_velocity[0] + neighbor.velocity[0],
                avg_velocity[1] + neighbor.velocity[1]
            )
        
        # 求平均速度
        avg_velocity = (
            avg_velocity[0] / len(neighbors),
            avg_velocity[1] / len(neighbors)
        )
        
        return normalize_vector(avg_velocity)
    
    def cohesion(self, neighbors):
        """凝聚规则：向邻居的中心移动"""
        if not neighbors:
            return (0, 0)
        
        # 计算邻居的平均位置
        avg_position = (0, 0)
        for neighbor in neighbors:
            avg_position = (
                avg_position[0] + neighbor.position[0],
                avg_position[1] + neighbor.position[1]
            )
        
        avg_position = (
            avg_position[0] / len(neighbors),
            avg_position[1] / len(neighbors)
        )
        
        # 计算指向平均位置的向量
        cohesion_vector = (
            avg_position[0] - self.position[0],
            avg_position[1] - self.position[1]
        )
        
        return normalize_vector(cohesion_vector)
    
    def avoid_edges(self):
        """避免边缘，当靠近窗口边缘时转向"""
        turn = (0, 0)
        
        # 左边缘
        if self.position[0] < PERCEPTION_RADIUS:
            turn = (turn[0] + TURN_FACTOR, turn[1])
        # 右边缘
        elif self.position[0] > WINDOW_WIDTH - PERCEPTION_RADIUS:
            turn = (turn[0] - TURN_FACTOR, turn[1])
        
        # 上边缘
        if self.position[1] < PERCEPTION_RADIUS:
            turn = (turn[0], turn[1] + TURN_FACTOR)
        # 下边缘
        elif self.position[1] > WINDOW_HEIGHT - PERCEPTION_RADIUS:
            turn = (turn[0], turn[1] - TURN_FACTOR)
        
        return turn
    
    def update(self, boids):
        """更新Boid的位置和速度"""
        neighbors = self.get_neighbors(boids)

        # 计算三个规则的向量
        separation = self.separation(neighbors)
        alignment = self.alignment(neighbors)
        cohesion = self.cohesion(neighbors)
        edge_avoidance = self.avoid_edges()

        # 应用权重并合并向量
        new_velocity = (
            self.velocity[0] * 0.8 +  # 引入惯性，保留部分当前速度
            separation[0] * SEPARATION_WEIGHT +
            alignment[0] * ALIGNMENT_WEIGHT +
            cohesion[0] * COHESION_WEIGHT +
            edge_avoidance[0],

            self.velocity[1] * 0.8 +  # 引入惯性，保留部分当前速度
            separation[1] * SEPARATION_WEIGHT +
            alignment[1] * ALIGNMENT_WEIGHT +
            cohesion[1] * COHESION_WEIGHT +
            edge_avoidance[1]
        )

        # 限制速度在最大和最小之间
        self.velocity = limit_vector(new_velocity, MAX_SPEED, MIN_SPEED)

        # 更新位置
        new_x = self.position[0] + self.velocity[0]
        new_y = self.position[1] + self.velocity[1]

        # 边界处理 - 从另一边出现
        if new_x < 0:
            new_x = WINDOW_WIDTH
        elif new_x > WINDOW_WIDTH:
            new_x = 0

        if new_y < 0:
            new_y = WINDOW_HEIGHT
        elif new_y > WINDOW_HEIGHT:
            new_y = 0

        self.position = (new_x, new_y)
