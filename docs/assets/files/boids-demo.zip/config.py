# 窗口配置
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 900
BACKGROUND_COLOR = (0, 0, 0)  # 黑色背景
BOID_COLOR = (255, 255, 255)  # 白色个体

# Boid群体配置
BOID_COUNT = 80  # 个体数量
BOID_SIZE = 10    # 个体大小（三角形的大小）

# 运动参数
MAX_SPEED = 20.5  # 最大速度
MIN_SPEED = 1.0  # 最小速度，增加最小速度以减少个体聚集
TURN_FACTOR = 0.2  # 转向因子，避免边缘

# 规则参数（权重）
PERCEPTION_RADIUS = 50  # 感知半径，能看到的邻居范围
SEPARATION_WEIGHT = 2.0  # 增加分离权重
ALIGNMENT_WEIGHT = 10.5   # 对齐规则权重
COHESION_WEIGHT = 0.8    # 降低凝聚权重
SEPARATION_DISTANCE = 20  # 分离最小距离

# 程序运行参数
FPS = 60  # 帧率
