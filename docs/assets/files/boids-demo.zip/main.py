import pygame
import sys
import argparse
from config import *
from boids import Boid
from utils import draw_boid, debug_print

def main(debug_mode=False):
    """主函数：初始化并运行Boids模拟"""
    # 初始化Pygame
    pygame.init()
    
    # 创建窗口
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Boids 算法模拟器")
    
    # 创建时钟，控制帧率
    clock = pygame.time.Clock()
    
    # 创建Boid群体
    boids = [Boid() for _ in range(BOID_COUNT)]
    
    # 帧计数器，用于调试信息
    frame_count = 0
    
    # 主循环
    running = True
    while running:
        # 处理事件
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            # 按ESC键退出
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
        
        # 填充背景色
        screen.fill(BACKGROUND_COLOR)
        
        # 更新所有Boid
        for boid in boids:
            boid.update(boids)
        
        # 绘制所有Boid
        for boid in boids:
            draw_boid(screen, boid)
        
        # 刷新屏幕
        pygame.display.flip()
        
        # 控制帧率
        clock.tick(FPS)
        
        # 调试模式：每10帧打印一次信息
        frame_count += 1
        if debug_mode and frame_count % 10 == 0:
            debug_print(frame_count, boids)
    
    # 退出程序
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='Boids算法模拟器')
    parser.add_argument('--debug', action='store_true', help='启用调试模式，输出详细信息')
    args = parser.parse_args()
    
    # 运行主函数
    main(args.debug)
