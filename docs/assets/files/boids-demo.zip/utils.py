import math
import pygame
from config import *

def distance(point1, point2):
    """计算两点之间的距离"""
    return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])** 2)

def normalize_vector(v):
    """归一化向量"""
    length = math.sqrt(v[0]**2 + v[1]** 2)
    if length == 0:
        return (0, 0)
    return (v[0] / length, v[1] / length)

def limit_vector(v, max_limit, min_limit=None):
    """限制向量的大小在最大和最小限制之间"""
    length = math.sqrt(v[0]**2 + v[1]** 2)
    
    if length > max_limit:
        return (v[0] * max_limit / length, v[1] * max_limit / length)
    if min_limit and length < min_limit:
        return (v[0] * min_limit / length, v[1] * min_limit / length)
    return v

def draw_boid(screen, boid):
    """绘制Boid个体（朝向运动方向的尖三角形）"""
    # 计算三角形的三个点
    angle = math.atan2(boid.velocity[1], boid.velocity[0])
    
    # 尖端点（前方）
    point1 = (
        boid.position[0] + BOID_SIZE * math.cos(angle),
        boid.position[1] + BOID_SIZE * math.sin(angle)
    )
    
    # 两个后点
    angle1 = angle + math.pi * 0.75
    point2 = (
        boid.position[0] + BOID_SIZE * 0.5 * math.cos(angle1),
        boid.position[1] + BOID_SIZE * 0.5 * math.sin(angle1)
    )
    
    angle2 = angle - math.pi * 0.75
    point3 = (
        boid.position[0] + BOID_SIZE * 0.5 * math.cos(angle2),
        boid.position[1] + BOID_SIZE * 0.5 * math.sin(angle2)
    )
    
    # 绘制三角形
    pygame.draw.polygon(screen, BOID_COLOR, [point1, point2, point3])

def debug_print(frame_count, boids):
    """调试模式下打印信息"""
    print(f"\n[调试信息] 第{frame_count}帧 | 总Boid数量: {len(boids)}")
    for i, boid in enumerate(boids[:5]):  # 只打印前5个Boid的信息，避免输出过多
        neighbors = boid.get_neighbors(boids)
        print(f"Boid {i}: 位置({boid.position[0]:.1f}, {boid.position[1]:.1f}) | "
              f"速度({boid.velocity[0]:.1f}, {boid.velocity[1]:.1f}) | 邻居数: {len(neighbors)}")
    if len(boids) > 5:
        print(f"... 省略剩余{len(boids)-5}个Boid的信息")
