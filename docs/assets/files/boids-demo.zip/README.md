# Boids算法模拟器

这是一个基于经典Boids算法的群体行为模拟器，模拟鱼群、鸟群等生物的群体运动行为。

## 算法原理

Boids算法通过三条简单的规则模拟群体行为：
1. **分离**：个体尽量远离附近的其他个体，避免碰撞
2. **对齐**：个体尽量与周围邻居的运动方向保持一致
3. **凝聚**：个体尽量向周围邻居的中心位置移动

通过这三条规则的相互作用，可以涌现出类似自然界中群体生物的复杂行为。

## 文件结构

- `main.py`：程序主入口，负责初始化、事件处理和主循环
- `boids.py`：实现Boid类和核心算法逻辑
- `config.py`：参数配置中心，所有可调节参数集中管理
- `utils.py`：工具函数库，包括向量计算、绘图等辅助功能
- `README.md`：项目说明文档

## 运行方法

### 前提条件
- Python 3.8+
- Pygame库

### 安装依赖pip install pygame
### 运行程序

#### 正常模式# Windows
python main.py

# macOS/Linux
python3 main.py
#### 调试模式
调试模式下会在终端输出Boid的位置、速度和邻居数量等信息：# Windows
python main.py --debug

# macOS/Linux
python3 main.py --debug
## 参数调整

所有可调节参数都在`config.py`文件中，主要包括：

- 窗口大小（WINDOW_WIDTH, WINDOW_HEIGHT）
- Boid数量（BOID_COUNT）
- 速度限制（MAX_SPEED, MIN_SPEED）
- 感知半径（PERCEPTION_RADIUS）
- 三条规则的权重（SEPARATION_WEIGHT, ALIGNMENT_WEIGHT, COHESION_WEIGHT）

修改参数后，只需重新运行程序即可看到效果。

## 操作说明
- 点击窗口关闭按钮或按ESC键退出程序
